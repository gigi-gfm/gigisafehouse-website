# gigiSafeHOUSE Website

Official website for gigiSafeHOUSE, a 501(c)(3) nonprofit organization dedicated to removing financial barriers to healthcare access and combating obesity in families and communities.

**Established 2012 | Blue Springs, Missouri**

## 🏠 About

gigiSafeHOUSE draws inspiration from the Filipino Bahay Kubo — the traditional home that represents community, openness, and care for one another. Our mission is to love and serve those in need.

## 🌐 Website

- **Live Site**: [www.gigisafehouse.org](https://www.gigisafehouse.org)
- **Phone**: 816-427-5320

## 🚀 Deployment

This site is deployed on Cloudflare Pages.

### To Deploy:

1. Push changes to the `main` branch
2. Cloudflare Pages will automatically build and deploy

## 📁 Project Structure

```
/
├── index.html      # Main website
├── logo.png        # gigiSafeHOUSE logo
└── README.md       # This file
```

## 💝 Get Involved

- **Donate**: Support our mission financially
- **Volunteer**: Share your time and talents
- **Partner**: Organizations can collaborate with us

## 📞 Contact

- **Location**: Blue Springs, Missouri
- **Phone**: [816-427-5320](tel:816-427-5320)
- **Website**: [www.gigisafehouse.org](https://www.gigisafehouse.org)

---

*"Here to Love and Serve"*

© 2025 gigiSafeHOUSE. All rights reserved.
